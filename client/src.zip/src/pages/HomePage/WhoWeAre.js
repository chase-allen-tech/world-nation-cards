/* eslint-disable */
// material
import { styled } from '@material-ui/core/styles'
import { Box, Grid, Container, Typography, Stack } from '@material-ui/core'
//
import {
  MotionInView,
  varFadeInUp,
  varFadeInDown,
} from '../../components/animate'

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  padding: theme.spacing(28, 0),
  backgroundColor: theme.palette.grey[100],
}))

const ContentStyle = styled('div')(({ theme }) => ({
  textAlign: 'center',
  position: 'relative',
  // marginBottom: theme.spacing(10),
  // [theme.breakpoints.up('md')]: {
  //   height: '100%',
  //   marginBottom: 0,
  //   textAlign: 'left',
  //   display: 'inline-flex',
  //   flexDirection: 'column',
  //   justifyContent: 'center',
  //   alignItems: 'flex-start',
  // },
}))

// ----------------------------------------------------------------------

export default function WhoWeAre() {
  return (
    <RootStyle>
      <Container maxWidth="lg" sx={{ position: 'relative' }}>
        <ContentStyle>
          <MotionInView variants={varFadeInUp}>
            <Stack direction="row" justifyContent="center">
              <img src="/images/logoBlack.png" alt="logo black" />
            </Stack>
          </MotionInView>
          <MotionInView variants={varFadeInUp}>
            <Typography
              variant="h2"
              align="center"
              sx={{ mb: 3, color: 'common.white' }}
            >
              Who we are
            </Typography>
          </MotionInView>

          <MotionInView variants={varFadeInUp}>
            <Typography align="center" sx={{ color: 'common.white', mb: 5 }}>
              We are all members
            </Typography>
          </MotionInView>
        </ContentStyle>
      </Container>
    </RootStyle>
  )
}
