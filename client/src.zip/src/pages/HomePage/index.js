/* eslint-disable */
// material
import { styled } from '@material-ui/core/styles'
// components
import Page from '../../components/Page'
import {
  LandingHero,
  LandingHowWork,
  LandingEquipment,
  LandingAbout,
  LandingCategory,
  LandingDamage,
  LandingConnect,
} from '../../components/_external-pages/landing'
import WhoWeAre from './WhoWeAre'
import MainHero from './MainHero'
import { CarouselBasic3 } from 'components/carousel'

// ----------------------------------------------------------------------

const RootStyle = styled(Page)({
  paddingTop: 176,
  paddingBottom: 88,
  height: '100%',
})

const ContentStyle = styled('div')(({ theme }) => ({
  overflow: 'hidden',
  position: 'relative',
  backgroundColor: theme.palette.background.default,
}))

// ----------------------------------------------------------------------

export default function HomePage() {
  return (
    <RootStyle>
      <ContentStyle>
        <CarouselBasic3 />
        <WhoWeAre />
        <LandingCategory />
        <LandingHowWork />
        <LandingEquipment />
        <LandingDamage />
        <LandingConnect />
      </ContentStyle>
    </RootStyle>
  )
}
