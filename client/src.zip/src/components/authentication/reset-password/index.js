export { default as ResetPasswordForm } from './ResetPasswordForm';
