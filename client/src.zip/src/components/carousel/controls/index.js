export { default as CarouselControlsPaging1 } from './CarouselControlsPaging1';
export { default as CarouselControlsPaging2 } from './CarouselControlsPaging2';
export { default as CarouselControlsArrowsBasic1 } from './CarouselControlsArrowsBasic1';
export { default as CarouselControlsArrowsBasic2 } from './CarouselControlsArrowsBasic2';
export { default as CarouselControlsArrowsBasic3 } from './CarouselControlsArrowsBasic3';
export { default as CarouselControlsArrowsIndex } from './CarouselControlsArrowsIndex';
